package org.coderstone.RoomScheduling;
import java.time.LocalDateTime;

//Reservation class stores information about each individual reservation that is made
public class Reservation {
	private int repeating;
	private String name;
	private String reserver;
	private LocalDateTime sday;
	private LocalDateTime eday;
	
	//Constructor formats information into a date and time to be reserved
    public Reservation(int s, int e, int d, int r, String n, String w) {
    	sday=LocalDateTime.now();
    	sday=sday.plusDays(d);
    	sday=sday.withHour(s/4);
    	sday=sday.withMinute((s%4)*15);
    	sday=sday.withSecond(0).withNano(0);
    	eday=sday;
    	eday=eday.withHour(e/4);
    	eday=eday.withMinute((e%4)*15);
    	name=n;
    	reserver=w;
    	repeating = r;
    }
    public String toString2() {
    	return reserver+sday+eday+name;
    }
    public String toString() {
    	return "Reserved by " + reserver + " from "+sday+" until "+eday + " for " + name;
    }
    
    public int getRepeating() {return repeating;}
    public LocalDateTime getSDay() {
    	return sday;
    }
    public LocalDateTime getEDay() {
    	return eday;
    }
    public String getName() {return name;}
    public String getReserver() {return reserver;}
}
