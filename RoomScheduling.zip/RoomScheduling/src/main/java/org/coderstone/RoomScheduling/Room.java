package org.coderstone.RoomScheduling;
import java.time.LocalDateTime;
import java.util.*;

public class Room {
	String name;
	String building;
	String number;
	
	Time[][] times = new Time[30][96];
	
	ArrayList<Reservation> events = new ArrayList<Reservation>();
	
	public Room(String name, String building, String number) {
		this.name = name;
		this.building = building;
		this.number = number;
		
		for(int i = 0; i < 30; i++) {
			for(int j = 0; j < 96; j++) {
				times[i][j] = new Time();
			}
		}
	}
	
	boolean checkFree(int start, int end, int day) {
		//returns true if a reservation between the start and end points on the given day is completely free
		for(int i = start; i < end; i++) {
			if(times[day][i].status == 2) return false;
		}
		return true;
	}
	
	boolean newRes(int start, int end, int day, int repeating, String name, String reserver) {
		if(repeating == 0 && checkFree(start, end, day)) {
			
			for(int i = 0; i < events.size(); i++) {
				if(events.get(i).getSDay().isAfter(LocalDateTime.now().plusDays(day).withHour(start/4).withMinute((start%4)*15).withSecond(0).withNano(0))) {
					events.add(i, new Reservation(start, end, day, repeating, name, reserver));
					break;
				}
			}
			
			for(int i = start; i <= end; i++) times[day][i].status = 2;
		}
		else {
			for(int i = 0; i < 30; i += repeating) if(!checkFree(start, end, day+i)) return false;
			for(int j = 0; j < 30; j += repeating) {
				
				for(int i = 0; i < events.size(); i++) {
					if(events.get(i).getSDay().isAfter(LocalDateTime.now().plusDays(day+j).withHour(start/4).withMinute((start%4)*15).withSecond(0).withNano(0))) {
						events.add(i, new Reservation(start, end, day+j, repeating, name, reserver));
						break;
					}
				}
			}
		}
		return true;
	}
	public String toString() {
		return name +" | "+building+" | "+number;
	}
}
