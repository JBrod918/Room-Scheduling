package org.coderstone.RoomScheduling;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class Room {
	String name;
	String building;
	String number;
	int coolIndex=0;
	Time[][] times = new Time[30][96];
	
	ArrayList<Reservation> events = new ArrayList<Reservation>();
	
	public Room(String name, String building, String number) {
		this.name = name;
		this.building = building;
		this.number = number;
		
		for(int i = 0; i < 30; i++) {
			for(int j = 0; j < 96; j++) {
				times[i][j] = new Time();
			}
		}
	}
	
	boolean checkFree(int start, int end, int day) {
		//returns true if a reservation between the start and end points on the given day is completely free
		for(int i = start; i < end && i < 96; i++) {
			if(times[day][i].status == 2) return false;
		}
		return true;
	}
	
	int indexOfReservation(int day, int start) {
		int index = 0;
		for(int i = 0; i < events.size(); i++) {
			long temp = (events.get(i).getSDay().getHour()*4) + (events.get(i).getSDay().getMinute()/15);
			long otherTemp = LocalDateTime.now().until(events.get(i).getSDay(), ChronoUnit.DAYS);
			if(otherTemp+1 == day && (int) temp == start) {
				index = i;
			}
		}
		
		return index;
	}
	
	void deleteRes(int day, int start) {
		events.remove(this.indexOfReservation(day, start));
	}
	boolean newRes(int start, int end, int day, int repeating, String name, String reserver) {
		if(day >= 30 || day < 0) return false;
		if(end <= start || day < 0) return false;
		if(repeating == 0 && checkFree(start, end, day)) {
			
			
			
			if(events.size() == 0) events.add(new Reservation(start, end, day, repeating, name, reserver));
			else {
				for(int i = 0; i < events.size(); i++) {
					if(i == events.size()-1) {
						if(events.get(i).getSDay().isAfter(LocalDateTime.now().plusDays(day).withHour((int)start/4).withMinute((start%4)*15).withSecond(0).withNano(0))) 
							events.add(i, new Reservation(start, end, day, repeating, name, reserver));
						else events.add(new Reservation(start, end, day, repeating, name, reserver));
						break;
					}
					if(events.get(i).getSDay().isAfter(LocalDateTime.now().plusDays(day).withHour((int)start/4).withMinute((start%4)*15).withSecond(0).withNano(0))) {
						events.add(i, new Reservation(start, end, day, repeating, name, reserver));
						break;
					}
				}
			}
			
			
			
			for(int i = start; i <= end; i++) times[day][i].status = 2;
		}
		else {
			for(int i = 0; i+day < 30; i += repeating) if(!checkFree(start, end, day+i)) return false;
			for(int j = 0; j+day < 30; j += repeating) {
				
				if(events.size() == 0) events.add(new Reservation(start, end, day+j, repeating, name, reserver));
				else {
					for(int i = 0; i < events.size(); i++) {
						if(events.get(i).getSDay().isAfter(LocalDateTime.now().plusDays(day+j).withHour((int)start/4).withMinute((start%4)*15).withSecond(0).withNano(0))) {
							events.add(i, new Reservation(start, end, day+j, repeating, name, reserver));
							break;
						}
						if(i == events.size()-1) {
							events.add(i, new Reservation(start, end, day+j, repeating, name, reserver));
							break;
						}
					}
				}
			}
		}
		return true;
	}
	
	public String getName() {
		return name;
	}
	public String toString() {
		return name +" | "+building+" | "+number;
	}
}
