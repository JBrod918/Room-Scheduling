package org.coderstone.RoomScheduling;

import static spark.Spark.*;
import java.io.*;
import java.util.*;

import java.time.LocalDateTime;

public class Main
{
	public static Room[] rooms=new Room[99];
	public static String bigBoi;
	public static Scanner s;
	public static Email sender = new Email();
	public static void main(String[]args)
	{
		staticFileLocation("/");
		try
		{
			
			s = new Scanner(new File("src/main/resources/rooms.txt"));
			for (int i=0;i<99;i++) {
				bigBoi=s.nextLine();
				String[] stuff=bigBoi.split(", ");
				rooms[i]=new Room(stuff[0],stuff[1],stuff[2]);
			}
			s.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		rooms[0].newRes(6, 10, 6, 0, "ESSO", "John");	
		rooms[0].newRes(7, 9, 6, 0, "Exonian", "Lisa");
		get("", (req, res) -> "RoomScheduling");
		post("/sched",(req,res)->
        {
        	String sprq=req.queryParams("sprq");
        	String email=req.queryParams("email");
        	String roomName=req.queryParams("roomName");
        	String reDay=req.queryParams("reDay");
        	String time=req.queryParams("time");
        	System.out.println(sprq);
        	System.out.println(email);
        	System.out.println(roomName);
        	System.out.println(reDay);
        	System.out.println(time);   
        	String[]rInfo=roomName.split("\\s\\|\\s",3);
        	LocalDateTime temp=LocalDateTime.now();
        	temp=temp.withSecond(0).withNano(0);
        	sender.send("wkw030210@gmail.com"+", "+email,"DGJASJFKW","ZA WARUDO TOKI YO TOMARE");
        	return "REQUEST RECEIVED";
        });
	}
	
	public String printAllRes() {
		String text = "";
		for(int i = 0; i < rooms.length; i++) {
			for(int j = 0; j < rooms[i].events.size(); j++) {
				text += rooms[i].events.get(j);
			}
		}
		return text;
	}
}
