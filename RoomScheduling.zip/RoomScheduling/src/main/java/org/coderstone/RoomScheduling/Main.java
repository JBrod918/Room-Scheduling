package org.coderstone.RoomScheduling;

import static spark.Spark.*;
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Main
{
	private static String adminemail="lightningtrackmc@gmail.com";
	public static Room[] rooms=new Room[99];
	public static String bigBoi;
	public static Scanner s;
	public static Email sender = new Email();
	public static void main(String[]args)
	{
		String projectDir = System.getProperty("user.dir");
		String staticDir = "/src/main/resources/";
		staticFiles.externalLocation(projectDir + staticDir);
		try
		{
			
			s = new Scanner(new File("src/main/resources/rooms.txt"));
			for (int i=0;i<99;i++) {
				bigBoi=s.nextLine();
				String[] stuff=bigBoi.split(", ");
				rooms[i]=new Room(stuff[0],stuff[1],stuff[2]);
			}
			s.close();
			
		    
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	    //Spark /sched subdirectory
		post("/sched",(req,res)->
        {
        	//Receive all variables and parse
        	String sprq=req.queryParams("sprq");
        	String email=req.queryParams("email");
        	String roomName=req.queryParams("roomName");
        	String reDay=req.queryParams("reDay");
        	String time=req.queryParams("time");
        	String end=req.queryParams("end");
        	String reserveName=req.queryParams("reserveName");
        	String reserver=req.queryParams("reserver");
        	String[]rInfo=roomName.split("\\s\\|\\s",3);
        	String[] datestuff=reDay.split("-");
        	String[] startstuff=time.split(":");
        	String[] endstuff=end.split(":");
        	
        	LocalDateTime start=LocalDateTime.now();
        	start=start.withYear(Integer.valueOf(datestuff[0])).withMonth(Integer.valueOf(datestuff[1])).withDayOfMonth(Integer.valueOf(datestuff[2])); 
        	start=start.withSecond(0).withNano(0);
        	LocalDateTime temp=LocalDateTime.now();
          	temp=temp.withSecond(0).withNano(0);
          	int days= (int) LocalDateTime.now().until(start, ChronoUnit.DAYS);
        	int index=0;
        	for(int i=0;i<rooms.length;i++)if(rooms[i].getName().equals(rInfo[0]))index=i;
        	int startInt = Integer.valueOf(startstuff[0])*4+Integer.valueOf(startstuff[1])/15;
        	if(rooms[index].newRes(startInt, Integer.valueOf(endstuff[0])*4+Integer.valueOf(endstuff[1])/15, days, 0, reserveName, reserver)) {
        		
        		
        		int reservindex=rooms[index].indexOfReservation(days, startInt);
        		String appr="approve"+rooms[index].events.get(reservindex).toString2();
        		String den="deny"+rooms[index].events.get(reservindex).toString2();
        		appr=appr.replaceAll("[^a-zA-Z]","");den=den.replaceAll("[^a-zA-Z]","");
        		appr="/"+appr+".html";den="/"+den+".html";
        		File approve=new File("src/main/resources/approve.html");
        		File deny=new File("src/main/resources/deny.html");
        		FileWriter appf=new FileWriter("src/main/resources"+appr,false);
        		FileWriter denf=new FileWriter("src/main/resources"+den,false);
        		PrintWriter denp=new PrintWriter(denf,false);
        		PrintWriter appp=new PrintWriter(appf,false);
        		appp.flush();
        		try
        		{
        			s = new Scanner(approve);
        			while(s.hasNextLine())appp.write(s.nextLine().replace("DDDDDDDDDD",""+index+" "+reservindex+" "+email+" "+appr+" "+den)+"\n");
        			s.close();
        			s = new Scanner(deny);
        			while(s.hasNextLine())denp.write(s.nextLine().replace("DDDDDDDDDD",""+index+" "+reservindex+" "+email+" "+appr+" "+den)+"\n");
        			s.close();
        		} catch (Exception e) {
        			e.printStackTrace();
        		}
        		appf.close();appp.close();denf.close();denp.close();
        		
        		String adminbody=reserver+" has reserved "+rInfo[0]+" for "+reserveName+" during "+time+" to "+end+" on "+start.getMonth()+" "+start.getDayOfMonth()+" with special requests "+sprq+".";
        		String adminsubject="Room Reservation Request "+rInfo[0]+" "+rInfo[1];
        		sender.send(adminemail,adminsubject,adminbody,"http://localhost:4567"+appr,"http://localhost:4567/"+den);
        		sender.send(email,"Room Reservation","You have succesfully requested for the room "+rInfo[0]+" for "+reserveName+" during "+time+" to "+end+" on "+start.getMonth()+" "+start.getDayOfMonth()+" .");
        		
        		FileWriter fwOb = new FileWriter("src/main/resources/res.txt", false); 
                PrintWriter pwOb = new PrintWriter(fwOb, false);
                pwOb.flush();
                pwOb.write(printAllRes());
                pwOb.close();
                fwOb.close();
        		return "REQUEST RECEIVED";
        	}else {
        		return "REQUEST DENIED";
        	}
        	
        });
		//spark approve subdirectory
		post("/approve",(req,res)->{
			String resnum=req.queryParams("ReservationNumber");
			String comments=req.queryParams("Comments");
			String rn[]=resnum.split("\\s");
			int index=Integer.parseInt(rn[0]);
			int reserveindex=Integer.parseInt(rn[1]);
			String email=rn[2];
			sender.send(email,"Reservation Request Accepted","Your reservation request was approved.\n"+rooms[index].events.get(reserveindex)+"\n"+comments);
			File k=new File("src/main/resources"+rn[3]);
			File l=new File("src/main/resources"+rn[4]);
			k.delete();l.delete();
			return "REQUEST APPROVED";
		});
		//spark deny subdirectory
		post("/deny",(req,res)->{
			String resnum=req.queryParams("ReservationNumber");
			String comments=req.queryParams("Comments");
			String rn[]=resnum.split("\\s");
			int index=Integer.parseInt(rn[0]);
			int reserveindex=Integer.parseInt(rn[1]);
			String email=rn[2];
			sender.send(email,"Reservation Request Denied","Your reservation request was denied.\n"+rooms[index].events.get(reserveindex)+"\n"+comments);
			File k=new File("src/main/resources"+rn[3]);
			File l=new File("src/main/resources"+rn[4]);
			k.delete();l.delete();
			rooms[index].events.remove(reserveindex);
			FileWriter fwOb = new FileWriter("src/main/resources/res.txt", false); 
            PrintWriter pwOb = new PrintWriter(fwOb, false);
            pwOb.flush();
            pwOb.write(printAllRes());
            pwOb.close();
            fwOb.close();
			return "REQUEST DENIED";
		});
	}
	
	public static String printAllRes() {
		String text = "";
		@SuppressWarnings("unused")
		String checker = "";
		for(int i = 0; i < rooms.length; i++) {
			text += "\n" + rooms[i].building + ": " + rooms[i].name + " - ";
			if(rooms[i].events.size() != 0) {
				checker = text;
				for(int j = 0; j < rooms[i].events.size(); j++) {
					text += rooms[i].events.get(j) + "\n";
				}
			}
		}
		return text;
	}
}
