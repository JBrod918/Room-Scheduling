package org.coderstone.RoomScheduling;

import java.util.*; 
import javax.mail.*; 
import javax.mail.internet.*;

//Email class sends emails
public class Email  
{ 
	public Email()
	{
	}
	//Send methods send emails from pearoomreservation@gmail.com to a given email
	
	public void send(String recipient,String subject,String body,String approve,String deny)  
	   {
		//this send method is to an administrator for approval/denying a reservation
		   try 
		      {
			   	//SMTP SERVER PROPERTIES
			    Properties prop = System.getProperties();
			    prop.put("mail.smtp.host", "smtp.gmail.com");
		        prop.put("mail.smtp.port", "587");
		        prop.put("mail.smtp.auth", "true");
		        prop.put("mail.smtp.starttls.enable", "true");
		        //NEW EMAIL SESSION
			    @SuppressWarnings("unused")
				Session session = Session.getDefaultInstance(prop, new javax.mail.Authenticator() {
			        @Override
			        protected PasswordAuthentication getPasswordAuthentication() {
			            return new PasswordAuthentication("pearoomreservation@gmail.com", "JackZhang");
			        }
			    });
			    //EMAIL PROPERTIIES 
		         MimeMessage message = new MimeMessage(session);
		         message.setFrom(new InternetAddress("pearoomreservation@gmail.com"));
		         message.addRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient));
		         message.setSubject(subject);
		         //HTML EMAIL FORMMAT
		         MimeBodyPart bodyr=new MimeBodyPart();
		         body="<p>"+body+"</p>"+"<br>"+"<a href=\""+approve+"\">APPROVE</a><br>"+"<a href=\""+deny+"\">DENY</a><br>";
		         bodyr.setText(body,"UTF-8","html");
		         Multipart mp = new MimeMultipart();
		         mp.addBodyPart(bodyr);
		         message.setContent(mp);
		         //SEND EMAIL
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException mex)  
		      { 
		         mex.printStackTrace(); 
		      } 
	   } 
	   public void send(String recipient,String subject,String body)  
	   {
			//this send method is to notify the person trying to make the reservation what the result was
		   try 
		      {

			    Properties prop = System.getProperties();
			    prop.put("mail.smtp.host", "smtp.gmail.com");
		        prop.put("mail.smtp.port", "587");
		        prop.put("mail.smtp.auth", "true");
		        prop.put("mail.smtp.starttls.enable", "true");

			    @SuppressWarnings("unused")
				Session session = Session.getDefaultInstance(prop, new javax.mail.Authenticator() {
			        @Override
			        protected PasswordAuthentication getPasswordAuthentication() {
			            return new PasswordAuthentication("pearoomreservation@gmail.com", "JackZhang");
			        }
			    });
		         MimeMessage message = new MimeMessage(session);
		         message.setFrom(new InternetAddress("pearoomreservation@gmail.com"));
		         message.addRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient));
		         message.setSubject(subject);
		         MimeBodyPart bodyr=new MimeBodyPart();
		         body="<p>"+body+"</p>";
		         bodyr.setText(body,"UTF-8","html");
		         Multipart mp = new MimeMultipart();
		         mp.addBodyPart(bodyr);
		         message.setContent(mp);
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException mex)  
		      { 
		         mex.printStackTrace(); 
		      } 
	   } 
} 