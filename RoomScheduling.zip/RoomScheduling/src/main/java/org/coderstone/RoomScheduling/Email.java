package org.coderstone.RoomScheduling;

import java.util.*; 
import javax.mail.*; 
import javax.mail.internet.*;

public class Email  
{ 
	public Email()
	{
	}
	   public void send(String recipient,String subject,String body,String approve,String deny)  
	   {
		   try 
		      {

			    Properties prop = System.getProperties();
			    prop.put("mail.smtp.host", "smtp.gmail.com");
		        prop.put("mail.smtp.port", "587");
		        prop.put("mail.smtp.auth", "true");
		        prop.put("mail.smtp.starttls.enable", "true");

			    @SuppressWarnings("unused")
				Session session = Session.getDefaultInstance(prop, new javax.mail.Authenticator() {
			        @Override
			        protected PasswordAuthentication getPasswordAuthentication() {
			            return new PasswordAuthentication("pearoomreservation@gmail.com", "JackZhang");
			        }
			    });
		         MimeMessage message = new MimeMessage(session);
		         message.setFrom(new InternetAddress("pearoomreservation@gmail.com"));
		         message.addRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient));
		         message.setSubject(subject);
		         MimeBodyPart bodyr=new MimeBodyPart();
		         body="<p>"+body+"</p>"+"<br>"+"<a href=\""+approve+"\">APPROVE</a><br>"+"<a href=\""+deny+"\">DENY</a><br>";
		         bodyr.setText(body,"UTF-8","html");
		         Multipart multipart = new MimeMultipart();
		         multipart.addBodyPart(bodyr);
		         message.setContent(multipart);
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException mex)  
		      { 
		         mex.printStackTrace(); 
		      } 
	   } 
	   public void send(String recipient,String subject,String body)  
	   {
		   try 
		      {

			    Properties prop = System.getProperties();
			    prop.put("mail.smtp.host", "smtp.gmail.com");
		        prop.put("mail.smtp.port", "587");
		        prop.put("mail.smtp.auth", "true");
		        prop.put("mail.smtp.starttls.enable", "true");

			    @SuppressWarnings("unused")
				Session session = Session.getDefaultInstance(prop, new javax.mail.Authenticator() {
			        @Override
			        protected PasswordAuthentication getPasswordAuthentication() {
			            return new PasswordAuthentication("pearoomreservation@gmail.com", "JackZhang");
			        }
			    });
		         MimeMessage message = new MimeMessage(session);
		         message.setFrom(new InternetAddress("pearoomreservation@gmail.com"));
		         message.addRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient));
		         message.setSubject(subject);
		         MimeBodyPart bodyr=new MimeBodyPart();
		         body="<p>"+body+"</p>";
		         bodyr.setText(body,"UTF-8","html");
		         Multipart multipart = new MimeMultipart();
		         multipart.addBodyPart(bodyr);
		         message.setContent(multipart);
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException mex)  
		      { 
		         mex.printStackTrace(); 
		      } 
	   } 
} 