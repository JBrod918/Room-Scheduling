package org.coderstone.RoomScheduling;

import java.util.*; 
import javax.mail.*; 
import javax.mail.internet.*;

public class Email  
{ 
	public Email()
	{
	}
   public void send(String recipient,String subject,String body)  
   {
	   try 
	      {

		    Properties prop = System.getProperties();
		    prop.put("mail.smtp.host", "smtp.gmail.com");
	        prop.put("mail.smtp.port", "587");
	        prop.put("mail.smtp.auth", "true");
	        prop.put("mail.smtp.starttls.enable", "true");

		    @SuppressWarnings("unused")
			Session session = Session.getDefaultInstance(prop, new javax.mail.Authenticator() {
		        @Override
		        protected PasswordAuthentication getPasswordAuthentication() {
		            return new PasswordAuthentication("pearoomreservation@gmail.com", "JackZhang");
		        }
		    });
	         MimeMessage message = new MimeMessage(session);
	         message.setFrom(new InternetAddress("pearoomreservation@gmail.com"));
	         message.addRecipients(Message.RecipientType.TO,InternetAddress.parse(recipient));
	         message.setSubject("l;dgjlkas");
	         message.setText("akljfl;as");
	         Transport.send(message); 
	         System.out.println("Mail successfully sent"); 
	      } 
	      catch (MessagingException mex)  
	      { 
	         mex.printStackTrace(); 
	      } 
   } 
} 