package org.coderstone.RoomScheduling;
public class Time{
	//tokiyo tomare
	int status=0;
	public Time() {
		
	}
	public void setStat(int s) {
		status=s;
	}
	public int getStat() {
		return status;
	}
}
