package org.coderstone.RoomScheduling;

//Time class is used to hold information about each of the 15 minute intervals available to reserve
public class Time{
	int status=0;
	public Time() {
		
	}
	public void setStat(int s) {
		status=s;
	}
	public int getStat() {
		return status;
	}
}
